let mysql=require('mysql');

const con=mysql.createConnection({
    host:"localhost",
    user:"pardevel_root",
    password:"a6Nmk-r5$sg]",
    database: 'pardevel_SchoolDB'
});

con.connect(function(err){
    if(err) throw err;
    console.log("connected!");

});

module.exports=con;

